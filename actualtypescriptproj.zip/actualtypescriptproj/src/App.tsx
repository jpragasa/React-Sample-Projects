import React from 'react';
import logo from './logo.svg';
import './App.css';
import Person from './Person';
import { Country } from './Person';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Person
        name="Josh"
        email="josh@gmail.com"
        age={28}
        isMarried={false}
        friends={["Josh","Daniel","Jackie"]}
        country={Country.USA}
        />
      </header>
    </div>
  );
}

export default App;
