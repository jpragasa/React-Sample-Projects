import logo from './logo.svg';
import './App.css';
import Board from './Board';
import Game from './Game';
function App() {
  return (
    <Game/>
  );
}

export default App;
