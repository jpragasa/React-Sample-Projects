import { Link } from 'react-router-dom'

function NavBar() {
    return <nav>
        <Link to="/" className='navItem'>Home</Link>
        <Link to="/menu" className='navItem'>Menu</Link>
        <Link to="/contact/" className='navItem'>Contact</Link>
        <Link to="/contact/innerRoute" className='navItem'>Inner Route</Link>
    </nav>
}

export default NavBar;