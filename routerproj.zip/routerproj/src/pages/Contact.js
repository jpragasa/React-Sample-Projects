import {Link, useParams} from 'react-router-dom'
function Contact() {
    let {username} = useParams();
    return <section>
        <h1>This is {username}'s the contact page</h1>
        <Link to="/contact/innerRoute">Go to inner route</Link>
    </section>
}

export default Contact;