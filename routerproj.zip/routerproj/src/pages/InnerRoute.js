import { useNavigate, useParams } from "react-router-dom";
function InnerRoute() {
    let navigate = useNavigate();
    let {username} = useParams();
    return <section>
        <h1>This is {username}'s inner route</h1>
        <button onClick={() => {navigate("/")}}>Back to Home</button>
        </section>;
}

export default InnerRoute;