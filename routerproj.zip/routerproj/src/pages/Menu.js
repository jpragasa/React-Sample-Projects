function Menu() {
    return <h1>This is the Menu page</h1>;
}

export default Menu;