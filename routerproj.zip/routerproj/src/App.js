import './App.css';

import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home.js';
import Contact from './pages/Contact.js';
import Menu from './pages/Menu.js';
import NavBar from './pages/NavBar.js';
import InnerRoute from './pages/InnerRoute.js';
function App() {
  return (
    <header className="App">
      <Router>
          <NavBar></NavBar>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/menu' element={<Menu />} />
          <Route path='/contact/:username' element={<Contact />}/>
          {/* The below is for an error page */}
          <Route path='/contact/innerRoute' element={<InnerRoute/>}/>
          <Route path='*' element={<h1>Page not found....</h1>} />
        </Routes>
      </Router>
    </header>
  );
}

export default App;
