import { useState } from "react";
import { useContext } from "react";
import { AppContext } from "../App";
function ChangeProfile() {
    const {setName} = useContext(AppContext);
    const [newUsername, setNewUsername] = useState("");
    return <section>
        <input onChange={(event) => setNewUsername(event.target.value)}/>
        <button onClick={() => setName(newUsername)}>Change Username</button>
    </section>
}

export default ChangeProfile;