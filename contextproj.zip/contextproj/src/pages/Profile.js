import ChangeProfile from "./ChangeProfile";
import { AppContext } from "../App";
import { useContext } from "react";
function Profile() {
    const {name} = useContext(AppContext);
    return <section>
        Profile: {name}
        <ChangeProfile/>
    </section>
}

export default Profile;