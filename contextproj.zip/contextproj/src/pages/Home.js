import { useContext } from "react";
import { AppContext } from "../App";
function Home(){
    const {name} = useContext(AppContext);
    return <h1>{name}'s Home</h1>
}

export default Home;
