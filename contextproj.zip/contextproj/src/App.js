import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import NavBar from './pages/NavBar';
import Home from './pages/Home';
import Profile from './pages/Profile';
import { useState, createContext } from 'react';

export const AppContext = createContext();

function App() {
  const [name, setName] = useState("Josh");
  return (
    <section>
      <AppContext.Provider value={{ name, setName }}>
        <Router>
          <NavBar />
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/profile' element={<Profile />} />
          </Routes>
        </Router>
      </AppContext.Provider>
    </section>
  );
}

export default App;
