import './App.css';
import {useState} from 'react';
function App() {

  const [count, setCount] = useState(0);

  return (
    <section className="App">
      <button onClick={() => setCount(count + 1)}>Increase</button>
      <button onClick={() => setCount(count - 1)}>Decrease</button>
      <button onClick={() => setCount(0)}>Set To Zero</button>
      <h1>{count}</h1>
    </section>
  );
}

export default App;



  // const person = {
  //   name: "Josh",
  //   age: 28
  // };

  //const names = ["Josh", "Jake", "Jackie"];
  // const planets = [
  //   {name: "Mars", isGasPlanet: false},
  //   {name: "Earth", isGasPlanet: false},
  //   {name: "Jupiter", isGasPlanet: true},
  //   {name: "Venus", isGasPlanet: false},
  //   {name: "Neptune", isGasPlanet: true},
  //   {name: "Uranus", isGasPlanet: true},
  // ];

      // {/* <Job salary={90000} position="Senior SDE" company="Amazon" /> */}
      // {/* {
      //     names.map((name,key) => {
      //       return <h1 key={key}>{name}</h1>
      //     })
      // } */}
      // {/* <Planets planetsList={planets}/> */}


        {/* <button onClick={handleClick}>Show/Hide</button>
        {showText === true && <h1 style={{color: color}}>Hi! I'm Josh!</h1>}
        {<h1 style={{color: color}}>Hi! I'm Josh!</h1>} */}
      
      