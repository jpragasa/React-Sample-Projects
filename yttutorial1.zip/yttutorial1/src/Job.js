function Job(props) {
    return(
    <section>
        <h1></h1>
        <h2>Information</h2>
        <ul>
            <li ><em>{props.salary}</em></li>
            <li ><em>{props.position}</em></li>
            <li ><em>{props.company}</em></li>
        </ul>
    </section>)
}

export default Job;