function Planets(props) {
    return (
        <section>
            {
                props.planetsList.map((planet, key) => {
                    return planet.isGasPlanet ? <h1 key={key}>{planet.name}</h1 > : <div key={key}></div>
                })
            }
        </section>
    );
}

export default Planets;