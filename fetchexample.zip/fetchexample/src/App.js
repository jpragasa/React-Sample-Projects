import logo from './logo.svg';
import './App.css';
import Axios from "axios";
import { useEffect, useState } from "react"
// fetch("https://catfact.ninja/fact")
// .then((res) => res.json())
// .then((data) => {
//   alert(data.length);
// });





function App() {
  const [catFact, setCatFact] = useState("")
  const [name, setName] = useState("");
  const [age, setAge] = useState(null);
  const [excuse, setExcuse] = useState(null);
  const FetchCatData = () => {
    Axios.get("https://catfact.ninja/fact")
    .then((res) => {
      setCatFact(res.data.fact);
    });
  };
  useEffect(() => {
    FetchCatData();
  }, []);


  const FetchAgeData = () => {
    Axios.get(`https://api.agify.io/?name=${name}`)
    .then((res) => {
      setAge(res.data);
    })
  };

  useEffect(() => {
    FetchAgeData();
  }, []);

  const FetchExcuseData = (category) => {
    Axios.get(`https://excuser-three.vercel.app/v1/excuse/${category}/`)
    .then((res) => {
      console.log(res.data[0])
      setExcuse(res.data[0]);
    });
  };

  useEffect(() => {
  FetchExcuseData();
  },[]);

  return (
    <section className="App">
      <header className="App-header">
        <button onClick={FetchCatData}>Generate Cat Fact</button>
        <h1>{catFact}</h1>
        <input placeholder='Josh' onChange={(event) => setName(event.target.value)}></input>
        <button onClick={FetchAgeData}>Predict Age</button>
        <h1>Name: {age?.name}</h1>
        <h1>Predicted Age: {age?.age}</h1>
        <h1>Count: {age?.count}</h1>

        <h1>Generate Excuse</h1>
        <button onClick={() => FetchExcuseData("party")}>Party</button>
        <button onClick={() => FetchExcuseData("family")}>Family</button>
        <button onClick={() => FetchExcuseData("office")}>Office</button>
        <h1>ID:{excuse?.id}</h1>
        <h1>Category:{excuse?.category}</h1>
        <h1>{excuse?.excuse}</h1>
      </header>
    </section>
  );
}

export default App;
