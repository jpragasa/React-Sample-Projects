function Task(props) {
    return (
        <div className="task">
            <span style={{color : props.isComplete ? "green" : "black"}}>{props.taskName}</span>
            <button onClick={() => props.deleteTask(props.id)}>X</button>
            <button onClick={() => props.setCompleteFlag(props.id)}>Complete</button>
        </div>
    );
}

export default Task;