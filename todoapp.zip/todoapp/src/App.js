import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
import Task from './Task';
function App() {
  const [todoList, setTodoList] = useState([]);
  const [newTask, setNewTask] = useState("");
  const addTask = () => {
    const task = {
      id: todoList.length === 0 ? 1 : todoList[todoList.length - 1].id + 1,
      taskName: newTask,
      isComplete: false
    };
    setTodoList([...todoList, task]);
  };
  const deleteTask = (id) => {
    setTodoList([...todoList].filter((name) => {
      return name.id !== id;
    }))
  };

  const setCompleteFlag = (id) => {
    setTodoList([...todoList].map((task) => {
      return task.id === id ? {...task, isComplete: !task.isComplete} : task;
    }));
  };
  return (
    <main className="App">
      <section className="addTask">
        <input onChange={(e) => setNewTask(e.target.value)}/>
        <button onClick={addTask}>Add Task</button>
      </section>
      <section className="list">
        {
          todoList.map((task) => {
            return <Task  taskName={task.taskName} 
                          id={task.id} 
                          deleteTask={deleteTask} 
                          isComplete={task.isComplete} 
                          setCompleteFlag={setCompleteFlag}/>
          })
        }
      </section>
    </main>
  );
}

export default App;
