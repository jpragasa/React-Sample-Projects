import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home';
import Profile from './pages/Profile';
import NavBar from './pages/NavBar';
import { QueryClient, QueryClientProvider } from 'react-query';
function App() {
  const client = new QueryClient({
    defaultOptions: {
      //This specific set below allows you to NOT update fetch data if you switch tabs etc...
      queries: {
        // TRUE for if you want update, false if not
        refetchOnWindowFocus: true,
      }
    }
  });
  return (
    <section className="App">
      <QueryClientProvider client={client}>
        <Router>
          <NavBar />
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/profile' element={<Profile />} />
            <Route path='*' element={<h1>Page Not Found</h1>} />
          </Routes>
        </Router>
      </QueryClientProvider>


    </section>
  );
}

export default App;
