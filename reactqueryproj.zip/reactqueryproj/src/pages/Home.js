import Axios from 'axios'
import {useQuery} from 'react-query'
function Home() {
    const {data: catData, isLoading,error, refetch} = useQuery(["cat"], () => {
        return Axios.get("https://catfact.ninja/fact")
        .then((res) => res.data)
    }) 
    return <div>
        This is the homepage 
        <h1>
            {
                error ? <h1>Could Not Fetch Data</h1> : <h1></h1>
            }
        {
        isLoading ? <h1>Loading Data Now...</h1>:catData?.fact
        }
        </h1>
        <button onClick={() => refetch()}>Update Data</button>
    </div>
}

export default Home;