function Profile() {
    return <h1>This is the profile page</h1>
}

export default Profile;