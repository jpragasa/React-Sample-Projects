import Axios from 'axios'
import { useState } from 'react'

export const useCounter = (initialValue = 0) => {
    const [state, setState] = useState(initialValue);

    const increaseCounter = () => {
        setState((prev) => prev + 1);
    }

    const decreaseCounter = () => {
        setState((prev) => prev - 1);
    }

    const resetCounter = () => {
        setState(0);
    }

    return [state, increaseCounter, decreaseCounter, resetCounter];
}