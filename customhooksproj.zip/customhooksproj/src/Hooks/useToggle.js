/*
3 rules for making hooks:
    1. has to start with 'use'
    2. has to be at the highest level of a component
    3. has to be inside a component
*/
import { useState } from 'react';
export const useToggle = (initialValue = false) => {
    const [state, setState] = useState(initialValue);

    const toggle = () => {
        setState((prev) => !prev)
    }

    return [state, toggle];
}