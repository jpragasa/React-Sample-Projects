import Axios from 'axios'
import { useQuery } from 'react-query'
export const useGetCat = () => {
    const { data, isLoading:isCatLoading, refetch, error } = useQuery(["cat"], async () => {
        return Axios.get("https://catfact.ninja/fact").then((res) => res.data);
    });

    const refetchData = () => { alert("Data refetched"); refetch(); }
    // if(error) {

    // }
    return { data, isCatLoading, refetchData };
}