import Axios from 'axios'
import { useQuery } from 'react-query'
import {useGetCat} from '../Hooks/useGetCat'
import { useCounter } from './useCounter';
function Cat() {
    // for some reason, [] does not work with useQuery, use the following syntax
    //const {data}
    // you can also define a new name within the brackets
    // const {data:catData}
    // const {data, isLoading} = useQuery(["cat"], async () => {
    //     return Axios.get("https://catfact.ninja/fact").then((res) => res.data);
    // })


    const {data, isCatLoading, refetchData} = useGetCat();
    const [counter, increaseCounter, decreaseCounter, resetCounter] = useCounter();
    if(isCatLoading) return <h1>loading...</h1>;
    return (<div>
        {/* <h1>{data?.fact}</h1> */}
        <button onClick={refetchData}>Refetch</button>
        <h1>{data?.fact}</h1>
        <button onClick={increaseCounter}>Increase Counter</button>
        <button onClick={decreaseCounter}>Decrease Counter</button>
        <button onClick={resetCounter}>Reset Counter</button>
        <h1>Counter: {counter}</h1>
    </div>)
}

export default Cat;