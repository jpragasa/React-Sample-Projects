import logo from './logo.svg';
import './App.css';
import { useToggle } from './Hooks/useToggle';
import { QueryClient, QueryClientProvider } from 'react-query';
import Cat from './Hooks/Cat';
function App() {
  /*
    the below can be defined in 2 ways:
    1.   const [isVisible, toggle] = useToggle();
    2.   const {isVisible, toggle} = useToggle();

    *** arrays will allow you the leniency of choosing what to name the variables
    *** for objects, only the name defined in the hook/custom hook can be used
      *** If you need a custom name for objects, you can use the following syntax:
        const {isVisible:customName, toggle} = useToggle();
  */
  const [isVisible, toggle] = useToggle();
  const [isVisible2, toggle2] = useToggle();
  const client = new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnWindowFocus: true,
      }
    }
  });
  return (
    <div className="App">
      <QueryClientProvider client={client}>
        <button onClick={toggle}>{isVisible ? "Hide" : "Show"}</button>
        {isVisible && <h1>Hidden Text</h1>}
        <button onClick={toggle2}>{isVisible2 ? "Hide" : "Show"}</button>
        {isVisible2 && <h1>Hidden Text</h1>}
        <Cat/>
      </QueryClientProvider>
    </div>
  );
}

export default App;
