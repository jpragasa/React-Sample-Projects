// Packages
// npm install react-hook-form yup
// npm install @hookform/resolvers

import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
function Form() {

    // Schema for field validation, You can add more error messages within the function parentheses
    // especially within the required functions parentheses

    const schema = yup.object().shape({
        fullName: yup.string().required("Your Full Name is Required"),
        email: yup.string().email().required("Must enter in email format (xxx@xxx.com)"),
        age: yup.number().positive().integer().min(18).required("Only ages 18 and above may submit"),
        password: yup.string().min(4).max(20).required(),
        confirmPassword: yup
            .string()
            .oneOf([yup.ref("password"), null], "Password does not match")
            .required("this does not match your entered password")
    });

    // uses the useForm hook to handle registering, submitting, and getting the form error state
    // IMPORTANT: make sure to set up the resolver schema like below
    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });

    // onsubmit event handler
    const onSubmit = (data) => {
        console.log(data);
    }
    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <input type="text" placeholder="Full Name..." {...register("fullName")}></input>
            <p className='err'>{errors.fullName?.message}</p>
            <input type="email" placeholder="Email..." {...register("email")}></input>
            <p className='err'>{errors.email?.message}</p>
            <input type="number" placeholder="Age..." {...register("age")}></input>
            <p className='err'>{errors.age?.message}</p>
            <input type="password" placeholder="Password..." {...register("password")}></input>
            <p className='err'>{errors.password?.message}</p>
            <input type="password" placeholder="Confirm Password..." {...register("confirmPassword")}></input>
            <p className='err'>{errors.confirmPassword?.message}</p>
            <input type="submit"></input>
        </form>
    );
}

export default Form;