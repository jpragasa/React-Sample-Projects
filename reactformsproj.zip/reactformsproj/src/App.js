import logo from './logo.svg';
import './App.css';
import Form from './pages/Form.js'
function App() {
  return (
    <div className="App">
      <Form/>
    </div>
  );
}

export default App;
