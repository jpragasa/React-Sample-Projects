/*
Steps:
1. install proptypes: npm install prop-types
2. import Proptypes from "prop-types";
 */

import logo from './logo.svg';
import './App.css';
import Person from './Person';
function App() {
  return (
    <div className="App">
     <Person 
     name={5}
     email="Josh@gmail.com"
     age={28}
     isMarried={false}
     friends={["Daniel","Josh","Jackie"]}
     />
    </div>
  );
}

export default App;
